"use client"

import { useState } from "react"
import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import FeaturesGrid from "@/components/features-grid"
import Dashboard from "@/components/dashboard"
import WalletConnectModal from "@/components/wallet-connect-modal"
import OnboardingFlow from "@/components/onboarding-flow"
import { useSports } from "@/lib/context/sports-context"

export default function Home() {
  const { user, setUser, resetUser } = useSports()
  const [currentView, setCurrentView] = useState<"home" | "onboarding" | "dashboard">("home")
  const [walletConnectOpen, setWalletConnectOpen] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")

  const handleWalletConnect = (walletType: string) => {
    const mockAddress = `0x${Math.random().toString(16).slice(2, 10)}`
    setWalletAddress(mockAddress)
    setCurrentView("onboarding")
    console.log("[v0] Wallet connected:", walletType, mockAddress)
  }

  const handleOnboardingComplete = (username: string, avatar: string) => {
    setUser({
      username,
      avatar,
      walletAddress,
      joinedDate: new Date().toISOString(),
    })
    setCurrentView("dashboard")
    setWalletConnectOpen(false)
  }

  const handleDisconnect = () => {
    resetUser()
    setCurrentView("home")
    setWalletAddress("")
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        isConnected={!!user}
        onConnect={() => setWalletConnectOpen(true)}
        userProfile={user ? { username: user.username, avatar: user.avatar } : null}
        onDisconnect={handleDisconnect}
      />

      {currentView === "home" && (
        <>
          <HeroSection onConnect={() => setWalletConnectOpen(true)} />
          <FeaturesGrid />
        </>
      )}

      {currentView === "onboarding" && (
        <OnboardingFlow walletAddress={walletAddress} onComplete={handleOnboardingComplete} />
      )}

      {currentView === "dashboard" && <Dashboard />}

      <WalletConnectModal
        open={walletConnectOpen}
        onOpenChange={setWalletConnectOpen}
        onConnect={handleWalletConnect}
      />
    </div>
  )
}
