"use client"

import { useState, useCallback } from "react"
import { useSports } from "@/lib/context/sports-context"

interface BetPlacement {
  predictionId: number
  amount: number
  odds: number
}

export function useMemeBetting() {
  const { deductBalance, addBalance } = useSports()
  const [isPlacing, setIsPlacing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const placeBet = useCallback(
    async (bet: BetPlacement): Promise<boolean> => {
      setIsPlacing(true)
      setError(null)

      try {
        if (!deductBalance("froth", bet.amount)) {
          setError("Insufficient FROTH balance")
          return false
        }

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1200))

        console.log("[v0] Bet placed:", bet)
        return true
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to place bet")
        addBalance("froth", bet.amount) // Refund on error
        return false
      } finally {
        setIsPlacing(false)
      }
    },
    [deductBalance, addBalance],
  )

  const settleBet = useCallback(
    async (betId: number, won: boolean, amount: number): Promise<boolean> => {
      setIsPlacing(true)
      setError(null)

      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 800))

        if (won) {
          addBalance("froth", amount)
          console.log("[v0] Bet won:", amount)
        } else {
          console.log("[v0] Bet lost")
        }
        return true
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to settle bet")
        return false
      } finally {
        setIsPlacing(false)
      }
    },
    [addBalance],
  )

  return {
    placeBet,
    settleBet,
    isPlacing,
    error,
  }
}
