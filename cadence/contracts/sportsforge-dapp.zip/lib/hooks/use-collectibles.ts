"use client"

import { useState, useCallback } from "react"
import { useSports } from "@/lib/context/sports-context"

interface CollectibleTransaction {
  collectibleId: number
  price: number
  action: "buy" | "sell"
}

export function useCollectibles() {
  const { deductBalance, addBalance } = useSports()
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const buyCollectible = useCallback(
    async (transaction: CollectibleTransaction): Promise<boolean> => {
      setIsProcessing(true)
      setError(null)

      try {
        if (!deductBalance("flow", transaction.price)) {
          setError("Insufficient FLOW balance")
          return false
        }

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500))

        console.log("[v0] Collectible purchased:", transaction)
        return true
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to purchase collectible")
        addBalance("flow", transaction.price) // Refund on error
        return false
      } finally {
        setIsProcessing(false)
      }
    },
    [deductBalance, addBalance],
  )

  const sellCollectible = useCallback(
    async (transaction: CollectibleTransaction): Promise<boolean> => {
      setIsProcessing(true)
      setError(null)

      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500))

        addBalance("flow", transaction.price)
        console.log("[v0] Collectible sold:", transaction)
        return true
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to sell collectible")
        return false
      } finally {
        setIsProcessing(false)
      }
    },
    [addBalance],
  )

  return {
    buyCollectible,
    sellCollectible,
    isProcessing,
    error,
  }
}
