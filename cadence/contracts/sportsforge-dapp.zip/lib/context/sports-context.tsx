"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"

interface UserProfile {
  username: string
  avatar: string
  walletAddress: string
  joinedDate: string
}

interface TokenBalances {
  flow: number
  juice: number
  froth: number
}

interface SportsContextType {
  user: UserProfile | null
  balances: TokenBalances
  isLoading: boolean
  setUser: (user: UserProfile) => void
  updateBalances: (balances: Partial<TokenBalances>) => void
  deductBalance: (token: keyof TokenBalances, amount: number) => boolean
  addBalance: (token: keyof TokenBalances, amount: number) => void
  resetUser: () => void
}

const SportsContext = createContext<SportsContextType | undefined>(undefined)

export function SportsProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<UserProfile | null>(null)
  const [balances, setBalances] = useState<TokenBalances>({
    flow: 150.5,
    juice: 500,
    froth: 1200,
  })
  const [isLoading, setIsLoading] = useState(false)

  const setUser = useCallback((newUser: UserProfile) => {
    setUserState(newUser)
  }, [])

  const updateBalances = useCallback((newBalances: Partial<TokenBalances>) => {
    setBalances((prev) => ({ ...prev, ...newBalances }))
  }, [])

  const deductBalance = useCallback(
    (token: keyof TokenBalances, amount: number): boolean => {
      if (balances[token] >= amount) {
        setBalances((prev) => ({
          ...prev,
          [token]: prev[token] - amount,
        }))
        return true
      }
      return false
    },
    [balances],
  )

  const addBalance = useCallback((token: keyof TokenBalances, amount: number) => {
    setBalances((prev) => ({
      ...prev,
      [token]: prev[token] + amount,
    }))
  }, [])

  const resetUser = useCallback(() => {
    setUserState(null)
    setBalances({ flow: 150.5, juice: 500, froth: 1200 })
  }, [])

  return (
    <SportsContext.Provider
      value={{
        user,
        balances,
        isLoading,
        setUser,
        updateBalances,
        deductBalance,
        addBalance,
        resetUser,
      }}
    >
      {children}
    </SportsContext.Provider>
  )
}

export function useSports() {
  const context = useContext(SportsContext)
  if (!context) {
    throw new Error("useSports must be used within SportsProvider")
  }
  return context
}
