"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

interface HeroSectionProps {
  onConnect: () => void
}

export default function HeroSection({ onConnect }: HeroSectionProps) {
  return (
    <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background gradient effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-background to-background pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 mb-6 animate-slide-in">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm text-primary">Flow Forte Hackathon 2025</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-6 leading-tight animate-slide-in">
          The Ultimate Web3 Sports Metaverse
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-slide-in">
          Collect, manage, and compete with sports assets across fantasy basketball, football clubs, and collectibles
          trading on Flow blockchain.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 animate-slide-in">
          <Button
            onClick={onConnect}
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 group"
          >
            Start Playing
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-secondary text-secondary hover:bg-secondary/10 bg-transparent"
          >
            Learn More
          </Button>
        </div>

        {/* Feature highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-16">
          {[
            { label: "Fantasy Basketball", value: "$JUICE Staking" },
            { label: "Football Clubs", value: "NFT Trading" },
            { label: "Meme Betting", value: "$FROTH Volatility" },
          ].map((item, i) => (
            <div
              key={i}
              className="p-4 rounded-lg border border-border bg-card/50 backdrop-blur hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="text-sm text-muted-foreground">{item.label}</div>
              <div className="text-lg font-semibold text-primary mt-1">{item.value}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
