"use client"

import { Card } from "@/components/ui/card"
import { SaveAll as Basketball, Trophy, Coins, Zap, TrendingUp, Users } from "lucide-react"

const features = [
  {
    icon: Basketball,
    title: "Fantasy Basketball",
    description:
      "Draft lineups with aiSports NFTs and stake $JUICE for contests with instant payouts via Forte automation.",
    color: "from-primary to-secondary",
  },
  {
    icon: Trophy,
    title: "Football Club Management",
    description: "Create, trade, and manage clubs and players as NFTs. Simulate matches with probabilistic outcomes.",
    color: "from-secondary to-primary",
  },
  {
    icon: Coins,
    title: "Collectibles Marketplace",
    description: "List, trade, and vault collectibles with AI-driven valuations and personalized recommendations.",
    color: "from-primary to-secondary",
  },
  {
    icon: Zap,
    title: "Meme Betting",
    description: "Wager on predictions tied to $FROTH volatility. Mint meme NFTs through mini-games.",
    color: "from-secondary to-primary",
  },
  {
    icon: TrendingUp,
    title: "Analytics Dashboard",
    description: "Real-time performance graphs and asset stats powered by Find Labs APIs.",
    color: "from-primary to-secondary",
  },
  {
    icon: Users,
    title: "AI Recommendations",
    description: "Get personalized lineup suggestions and trade advice powered by Beezie AI.",
    color: "from-secondary to-primary",
  },
]

export default function FeaturesGrid() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Integrated Features</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Seamlessly combine multiple blockchain projects for a unified sports experience
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon
          return (
            <Card
              key={index}
              className="group p-6 border border-border bg-card hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
            >
              <div
                className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} p-2.5 mb-4 group-hover:scale-110 transition-transform`}
              >
                <Icon className="w-full h-full text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </Card>
          )
        })}
      </div>
    </section>
  )
}
