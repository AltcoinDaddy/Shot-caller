"use client"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useSports } from "@/lib/context/sports-context"
import FantasyBasketball from "@/components/modules/fantasy-basketball"
import FootballClubs from "@/components/modules/football-clubs"
import Collectibles from "@/components/modules/collectibles"
import MemeBetting from "@/components/modules/meme-betting"
import Analytics from "@/components/modules/analytics"
import AIRecommendations from "@/components/ai-recommendations"

export default function Dashboard() {
  const { balances } = useSports()

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Balance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {[
            { label: "FLOW Balance", value: balances.flow, symbol: "FLOW", color: "from-primary" },
            { label: "$JUICE Balance", value: balances.juice, symbol: "JUICE", color: "from-secondary" },
            { label: "$FROTH Balance", value: balances.froth, symbol: "FROTH", color: "from-primary" },
          ].map((token, i) => (
            <Card
              key={i}
              className={`p-6 border border-border bg-gradient-to-br ${token.color} to-background/50 hover:shadow-lg hover:shadow-primary/20 transition-all duration-300`}
            >
              <div className="text-sm text-muted-foreground mb-2">{token.label}</div>
              <div className="text-3xl font-bold text-foreground">{token.value}</div>
              <div className="text-xs text-muted-foreground mt-2">{token.symbol}</div>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="ai" className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-card border border-border mb-8">
            <TabsTrigger value="ai">AI Assistant</TabsTrigger>
            <TabsTrigger value="fantasy">Fantasy</TabsTrigger>
            <TabsTrigger value="clubs">Clubs</TabsTrigger>
            <TabsTrigger value="collectibles">Collectibles</TabsTrigger>
            <TabsTrigger value="betting">Betting</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="ai" className="space-y-6">
            <AIRecommendations />
          </TabsContent>

          <TabsContent value="fantasy" className="space-y-6">
            <FantasyBasketball />
          </TabsContent>

          <TabsContent value="clubs" className="space-y-6">
            <FootballClubs />
          </TabsContent>

          <TabsContent value="collectibles" className="space-y-6">
            <Collectibles />
          </TabsContent>

          <TabsContent value="betting" className="space-y-6">
            <MemeBetting />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Analytics />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
