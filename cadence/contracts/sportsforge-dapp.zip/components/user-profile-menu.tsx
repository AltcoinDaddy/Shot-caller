"use client"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { LogOut, Settings, User, Wallet } from "lucide-react"

interface UserProfileMenuProps {
  username: string
  avatar: string
  walletAddress: string
  onDisconnect: () => void
}

export default function UserProfileMenu({ username, avatar, walletAddress, onDisconnect }: UserProfileMenuProps) {
  const shortAddress = `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0 hover:bg-muted">
          <Avatar className="h-10 w-10">
            <AvatarFallback className="bg-primary text-primary-foreground text-lg">{avatar}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-card border-border">
        <div className="flex items-center gap-3 p-3 border-b border-border">
          <Avatar className="h-10 w-10">
            <AvatarFallback className="bg-primary text-primary-foreground text-lg">{avatar}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-foreground text-sm">{username}</p>
            <p className="text-xs text-muted-foreground font-mono">{shortAddress}</p>
          </div>
        </div>

        <DropdownMenuItem className="cursor-pointer text-foreground hover:bg-muted focus:bg-muted">
          <User className="w-4 h-4 mr-2" />
          <span>View Profile</span>
        </DropdownMenuItem>

        <DropdownMenuItem className="cursor-pointer text-foreground hover:bg-muted focus:bg-muted">
          <Wallet className="w-4 h-4 mr-2" />
          <span>Wallet Details</span>
        </DropdownMenuItem>

        <DropdownMenuItem className="cursor-pointer text-foreground hover:bg-muted focus:bg-muted">
          <Settings className="w-4 h-4 mr-2" />
          <span>Settings</span>
        </DropdownMenuItem>

        <DropdownMenuSeparator className="bg-border" />

        <DropdownMenuItem
          onClick={onDisconnect}
          className="cursor-pointer text-destructive hover:bg-destructive/10 focus:bg-destructive/10"
        >
          <LogOut className="w-4 h-4 mr-2" />
          <span>Disconnect</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
