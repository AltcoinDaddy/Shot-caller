"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, TrendingUp, Target, Zap, ChevronRight } from "lucide-react"

export default function AIRecommendations() {
  const [expandedId, setExpandedId] = useState(null)

  const recommendations = [
    {
      id: 1,
      type: "Fantasy Basketball",
      title: "Optimal Lineup for Tonight",
      description: "Based on player form and matchups, this lineup has 87% win probability",
      confidence: 87,
      action: "View Lineup",
      details: "LeBron James (SF) + Luka Doncic (PG) + Jayson Tatum (SF) + Nikola Jokic (C) + Stephen Curry (PG)",
      icon: Target,
    },
    {
      id: 2,
      type: "Collectibles",
      title: "Undervalued NFT Alert",
      description: "This collectible is 23% below market average for its rarity tier",
      confidence: 92,
      action: "View Collectible",
      details: "Legendary Player Card #4521 - Current: 450 FLOW, Market Average: 585 FLOW",
      icon: TrendingUp,
    },
    {
      id: 3,
      type: "Meme Betting",
      title: "High Probability Bet",
      description: "FVIX volatility patterns suggest 78% probability of spike in next 12h",
      confidence: 78,
      action: "Place Bet",
      details: "$FROTH Volatility Spike prediction with 2.5x odds",
      icon: Zap,
    },
    {
      id: 4,
      type: "Football Clubs",
      title: "Player Trade Recommendation",
      description: "Upgrade your striker with this emerging talent at fair market value",
      confidence: 84,
      action: "View Trade",
      details: "Trade your current striker for Player #2847 - Better form, lower salary cap",
      icon: Target,
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-primary/20">
          <Sparkles className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-foreground">AI Recommendations</h2>
          <p className="text-sm text-muted-foreground">Powered by Beezie AI</p>
        </div>
      </div>

      {/* AI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 border border-border bg-card">
          <p className="text-sm text-muted-foreground mb-1">Accuracy Rate</p>
          <p className="text-2xl font-bold text-primary">84.2%</p>
          <p className="text-xs text-primary mt-2">+2.1% this week</p>
        </Card>
        <Card className="p-4 border border-border bg-card">
          <p className="text-sm text-muted-foreground mb-1">Recommendations</p>
          <p className="text-2xl font-bold text-secondary">127</p>
          <p className="text-xs text-secondary mt-2">Followed this month</p>
        </Card>
        <Card className="p-4 border border-border bg-card">
          <p className="text-sm text-muted-foreground mb-1">Avg. ROI</p>
          <p className="text-2xl font-bold text-primary">+23.5%</p>
          <p className="text-xs text-primary mt-2">On recommended trades</p>
        </Card>
      </div>

      {/* Recommendations List */}
      <div className="space-y-3">
        {recommendations.map((rec) => {
          const IconComponent = rec.icon
          const isExpanded = expandedId === rec.id

          return (
            <Card
              key={rec.id}
              className="border border-border bg-card overflow-hidden transition-all duration-300 hover:border-primary/50"
            >
              <button
                onClick={() => setExpandedId(isExpanded ? null : rec.id)}
                className="w-full p-6 text-left hover:bg-background/50 transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10 flex-shrink-0">
                    <IconComponent className="w-5 h-5 text-primary" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div>
                        <p className="text-xs font-semibold text-primary uppercase tracking-wide">{rec.type}</p>
                        <h3 className="text-lg font-semibold text-foreground mt-1">{rec.title}</h3>
                      </div>
                      <ChevronRight
                        className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform ${
                          isExpanded ? "rotate-90" : ""
                        }`}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">{rec.description}</p>

                    <div className="mt-3 flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-background rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-primary to-secondary"
                            style={{ width: `${rec.confidence}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-primary">{rec.confidence}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-border px-6 py-4 bg-background/30">
                  <p className="text-sm text-muted-foreground mb-4">{rec.details}</p>
                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                    {rec.action}
                  </Button>
                </div>
              )}
            </Card>
          )
        })}
      </div>

      {/* AI Insights */}
      <Card className="p-6 border border-border bg-gradient-to-br from-primary/10 to-secondary/10">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          Market Insights
        </h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">
              Fantasy basketball contests show 34% higher ROI this week due to player form volatility
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-secondary mt-2 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">
              Collectible market trending toward Legendary tier - consider diversifying portfolio
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">
              FVIX index correlation with $FROTH volatility at 0.89 - strong predictive signal
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
