"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, CheckCircle2, Sparkles } from "lucide-react"

interface OnboardingFlowProps {
  walletAddress: string
  onComplete: (username: string, avatar: string) => void
}

export default function OnboardingFlow({ walletAddress, onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(1)
  const [username, setUsername] = useState("")
  const [selectedAvatar, setSelectedAvatar] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const avatarOptions = ["🏀", "⚽", "🎮", "🏆", "💎", "🚀"]

  const handleNext = async () => {
    if (step < 3) {
      setStep(step + 1)
    } else {
      setIsSubmitting(true)
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(username, avatarOptions[selectedAvatar])
      setIsSubmitting(false)
    }
  }

  const isStepValid = () => {
    if (step === 2) return username.trim().length > 0
    return true
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-4">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`flex-1 h-1 mx-1 rounded-full transition-all ${s <= step ? "bg-primary" : "bg-muted"}`}
              />
            ))}
          </div>
          <p className="text-sm text-muted-foreground text-center">Step {step} of 3</p>
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <Card className="p-8 border border-border bg-card">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-primary-foreground" />
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Welcome to SportsForge</h2>
              <p className="text-muted-foreground">
                You're about to enter the ultimate Web3 sports metaverse. Let's set up your profile!
              </p>
            </div>

            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-6">
              <p className="text-sm text-foreground">
                <span className="font-semibold">Wallet Connected:</span>
              </p>
              <p className="text-xs text-muted-foreground font-mono mt-1 break-all">{walletAddress}</p>
            </div>

            <Button
              onClick={handleNext}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Card>
        )}

        {/* Step 2: Profile Setup */}
        {step === 2 && (
          <Card className="p-8 border border-border bg-card">
            <h2 className="text-2xl font-bold text-foreground mb-6">Create Your Profile</h2>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Username</label>
                <Input
                  placeholder="Enter your SportsForge username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-background border-border text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  This will be your public display name on leaderboards and profiles.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Choose Your Avatar</label>
                <div className="grid grid-cols-6 gap-3">
                  {avatarOptions.map((avatar, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedAvatar(index)}
                      className={`p-4 rounded-lg border-2 transition-all text-2xl ${
                        selectedAvatar === index
                          ? "border-primary bg-primary/10"
                          : "border-border bg-background hover:border-primary/50"
                      }`}
                    >
                      {avatar}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <Button
                onClick={() => setStep(1)}
                variant="outline"
                className="flex-1 border-border text-foreground hover:bg-muted"
              >
                Back
              </Button>
              <Button
                onClick={handleNext}
                disabled={!isStepValid()}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                Continue
              </Button>
            </div>
          </Card>
        )}

        {/* Step 3: Starter Collectible */}
        {step === 3 && (
          <Card className="p-8 border border-border bg-card">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
                <span className="text-4xl">🎁</span>
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Claim Your Starter Collectible</h2>
              <p className="text-muted-foreground">
                Every new player gets a unique starter NFT to boost your first contests!
              </p>
            </div>

            <div className="bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 rounded-lg p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="font-semibold text-foreground">Legendary Starter Pack</p>
                  <p className="text-sm text-muted-foreground">Limited Edition NFT</p>
                </div>
                <span className="text-3xl">⭐</span>
              </div>
              <div className="space-y-2 text-sm">
                <p className="text-foreground">
                  <span className="text-primary">+25%</span> Fantasy Points Boost
                </p>
                <p className="text-foreground">
                  <span className="text-primary">+15%</span> Club Rating Boost
                </p>
                <p className="text-foreground">
                  <span className="text-primary">+10%</span> Collectible Trading Discount
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep(2)}
                variant="outline"
                className="flex-1 border-border text-foreground hover:bg-muted"
              >
                Back
              </Button>
              <Button
                onClick={handleNext}
                disabled={isSubmitting}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 gap-2 disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                {isSubmitting ? "Completing..." : "Complete Setup"}
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
