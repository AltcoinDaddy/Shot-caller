"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Wallet, Zap } from "lucide-react"

interface WalletConnectModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onConnect: (walletType: string) => void
}

export default function WalletConnectModal({ open, onOpenChange, onConnect }: WalletConnectModalProps) {
  const [isConnecting, setIsConnecting] = useState(false)

  const walletOptions = [
    {
      name: "Blocto",
      description: "Mobile-first wallet for Flow",
      icon: "🔐",
    },
    {
      name: "Dapper",
      description: "Official Flow wallet",
      icon: "💧",
    },
    {
      name: "Ledger",
      description: "Hardware wallet support",
      icon: "🔒",
    },
  ]

  const handleConnect = async (walletType: string) => {
    setIsConnecting(true)
    // Simulate wallet connection
    await new Promise((resolve) => setTimeout(resolve, 1500))
    onConnect(walletType)
    setIsConnecting(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-primary" />
            Connect Your Wallet
          </DialogTitle>
          <DialogDescription>Choose a wallet to connect to SportsForge and start playing</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-4">
          {walletOptions.map((wallet) => (
            <button
              key={wallet.name}
              onClick={() => handleConnect(wallet.name)}
              disabled={isConnecting}
              className="w-full p-4 rounded-lg border border-border bg-card hover:border-primary/50 hover:bg-card/80 transition-all duration-300 text-left disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-foreground">{wallet.name}</p>
                  <p className="text-sm text-muted-foreground">{wallet.description}</p>
                </div>
                <span className="text-2xl">{wallet.icon}</span>
              </div>
            </button>
          ))}
        </div>

        <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
          <p className="text-xs text-muted-foreground flex items-start gap-2">
            <Zap className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
            <span>
              By connecting, you agree to our Terms of Service and Privacy Policy. Your wallet address will be used to
              track your assets and transactions.
            </span>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
