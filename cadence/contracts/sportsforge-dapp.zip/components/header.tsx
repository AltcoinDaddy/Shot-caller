"use client"

import { Button } from "@/components/ui/button"
import { Zap } from "lucide-react"
import UserProfileMenu from "@/components/user-profile-menu"

interface HeaderProps {
  isConnected: boolean
  onConnect: () => void
  userProfile?: { username: string; avatar: string } | null
  onDisconnect?: () => void
}

export default function Header({ isConnected, onConnect, userProfile, onDisconnect }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">SportsForge</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Fantasy
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Clubs
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Collectibles
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Leaderboard
            </a>
          </nav>

          {isConnected && userProfile ? (
            <UserProfileMenu
              username={userProfile.username}
              avatar={userProfile.avatar}
              walletAddress="0x1234567890"
              onDisconnect={onDisconnect || (() => {})}
            />
          ) : (
            <Button
              onClick={onConnect}
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-all duration-300"
            >
              Connect Wallet
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}
