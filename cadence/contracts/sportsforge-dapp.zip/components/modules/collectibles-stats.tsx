"use client"

import { Card } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const portfolioData = [
  { date: "Week 1", value: 1200 },
  { date: "Week 2", value: 1450 },
  { date: "Week 3", value: 1380 },
  { date: "Week 4", value: 1650 },
  { date: "Week 5", value: 1920 },
]

export default function CollectiblesStats() {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-foreground">Your Collectibles Portfolio</h3>

      {/* Portfolio Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Total Value", value: "1,920 FLOW", change: "+18%" },
          { label: "Items Owned", value: "12", change: "+2 this week" },
          { label: "Avg Item Value", value: "160 FLOW", change: "+5%" },
          { label: "Portfolio Gain", value: "+720 FLOW", change: "+60%" },
        ].map((stat, i) => (
          <Card key={i} className="p-4 border border-border bg-card">
            <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-primary mt-2">{stat.change}</p>
          </Card>
        ))}
      </div>

      {/* Portfolio Growth Chart */}
      <Card className="p-6 border border-border bg-card">
        <h4 className="text-sm font-semibold text-foreground mb-4">Portfolio Growth</h4>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={portfolioData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#A0A0A0" />
            <YAxis stroke="#A0A0A0" />
            <Tooltip contentStyle={{ backgroundColor: "#252525", border: "1px solid #333" }} />
            <Line type="monotone" dataKey="value" stroke="#14B8A6" strokeWidth={2} dot={{ fill: "#14B8A6" }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Rarity Distribution */}
      <Card className="p-6 border border-border bg-card">
        <h4 className="text-sm font-semibold text-foreground mb-4">Collection by Rarity</h4>
        <div className="space-y-3">
          {[
            { rarity: "Legendary", count: 2, value: 550, color: "from-yellow-500" },
            { rarity: "Epic", count: 3, value: 510, color: "from-purple-500" },
            { rarity: "Rare", count: 5, value: 310, color: "from-blue-500" },
            { rarity: "Common", count: 2, value: 50, color: "from-gray-500" },
          ].map((item, i) => (
            <div key={i}>
              <div className="flex justify-between mb-2">
                <span className="text-sm text-foreground">{item.rarity}</span>
                <span className="text-sm font-semibold text-primary">{item.value} FLOW</span>
              </div>
              <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${item.color} to-secondary`}
                  style={{ width: `${(item.value / 1920) * 100}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">{item.count} items</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
