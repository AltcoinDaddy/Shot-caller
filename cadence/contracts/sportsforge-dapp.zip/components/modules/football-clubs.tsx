"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Users, TrendingUp, Play, Plus, Trophy, Zap } from "lucide-react"

interface Player {
  id: number
  name: string
  position: string
  rating: number
  value: number
  nftId: string
}

interface Club {
  id: number
  name: string
  owner: string
  players: Player[]
  rating: number
  wins: number
  losses: number
  draws: number
  league: string
  season: number
  nextMatch?: string
}

interface Match {
  id: number
  homeClub: string
  awayClub: string
  homeRating: number
  awayRating: number
  status: "Scheduled" | "Live" | "Completed"
  result?: string
  date: string
}

export default function FootballClubs() {
  const [clubs, setClubs] = useState<Club[]>([
    {
      id: 1,
      name: "Thunder United",
      owner: "You",
      players: [
        { id: 1, name: "Cristiano Ronaldo", position: "ST", rating: 94, value: 5000, nftId: "nft_001" },
        { id: 2, name: "Virgil van Dijk", position: "CB", rating: 92, value: 4500, nftId: "nft_002" },
        { id: 3, name: "Kevin De Bruyne", position: "CM", rating: 91, value: 4200, nftId: "nft_003" },
        { id: 4, name: "Erling Haaland", position: "ST", rating: 90, value: 4000, nftId: "nft_004" },
        { id: 5, name: "Vinicius Jr", position: "LW", rating: 89, value: 3800, nftId: "nft_005" },
        { id: 6, name: "Jude Bellingham", position: "CM", rating: 87, value: 3500, nftId: "nft_006" },
        { id: 7, name: "Florian Wirtz", position: "LW", rating: 86, value: 3200, nftId: "nft_007" },
        { id: 8, name: "Gianluigi Donnarumma", position: "GK", rating: 88, value: 3000, nftId: "nft_008" },
        { id: 9, name: "Rodri", position: "CM", rating: 89, value: 3800, nftId: "nft_009" },
        { id: 10, name: "Bukayo Saka", position: "RW", rating: 85, value: 3000, nftId: "nft_010" },
        { id: 11, name: "Declan Rice", position: "CM", rating: 84, value: 2800, nftId: "nft_011" },
      ],
      rating: 8.9,
      wins: 12,
      losses: 2,
      draws: 1,
      league: "Premier League",
      season: 2025,
      nextMatch: "vs Elite Strikers - Tomorrow 8:00 PM",
    },
    {
      id: 2,
      name: "Elite Strikers",
      owner: "Player2",
      players: [
        { id: 12, name: "Kylian Mbappe", position: "ST", rating: 93, value: 4800, nftId: "nft_012" },
        { id: 13, name: "Pedri", position: "CM", rating: 88, value: 3600, nftId: "nft_013" },
        { id: 14, name: "Gavi", position: "CM", rating: 86, value: 3200, nftId: "nft_014" },
      ],
      rating: 8.5,
      wins: 10,
      losses: 3,
      draws: 2,
      league: "Premier League",
      season: 2025,
      nextMatch: "vs Victory Squad - Next Monday 7:00 PM",
    },
    {
      id: 3,
      name: "Victory Squad",
      owner: "Player3",
      players: [
        { id: 15, name: "Harry Kane", position: "ST", rating: 89, value: 3800, nftId: "nft_015" },
        { id: 16, name: "Jamal Musiala", position: "LW", rating: 87, value: 3500, nftId: "nft_016" },
      ],
      rating: 7.8,
      wins: 8,
      losses: 5,
      draws: 2,
      league: "Premier League",
      season: 2025,
    },
  ])

  const [matches, setMatches] = useState<Match[]>([
    {
      id: 1,
      homeClub: "Thunder United",
      awayClub: "Elite Strikers",
      homeRating: 8.9,
      awayRating: 8.5,
      status: "Scheduled",
      date: "Tomorrow 8:00 PM",
    },
    {
      id: 2,
      homeClub: "Elite Strikers",
      awayClub: "Victory Squad",
      homeRating: 8.5,
      awayRating: 7.8,
      status: "Scheduled",
      date: "Next Monday 7:00 PM",
    },
    {
      id: 3,
      homeClub: "Thunder United",
      awayClub: "Victory Squad",
      homeRating: 8.9,
      awayRating: 7.8,
      status: "Completed",
      result: "3-1",
      date: "Last Saturday",
    },
  ])

  const [createClubOpen, setCreateClubOpen] = useState(false)
  const [newClubName, setNewClubName] = useState("")
  const [selectedClub, setSelectedClub] = useState<Club | null>(null)
  const [clubDetailOpen, setClubDetailOpen] = useState(false)
  const [simulateMatchOpen, setSimulateMatchOpen] = useState(false)
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)

  const handleCreateClub = () => {
    if (newClubName.trim()) {
      const newClub: Club = {
        id: clubs.length + 1,
        name: newClubName,
        owner: "You",
        players: [],
        rating: 0,
        wins: 0,
        losses: 0,
        draws: 0,
        league: "Premier League",
        season: 2025,
      }
      setClubs([...clubs, newClub])
      setNewClubName("")
      setCreateClubOpen(false)
    }
  }

  const handleSimulateMatch = (match: Match) => {
    setSelectedMatch(match)
    setSimulateMatchOpen(true)
  }

  const handleExecuteSimulation = () => {
    if (selectedMatch) {
      const homeWinChance = selectedMatch.homeRating / (selectedMatch.homeRating + selectedMatch.awayRating)
      const isHomeWin = Math.random() < homeWinChance

      const homeGoals = isHomeWin ? Math.floor(Math.random() * 3) + 2 : Math.floor(Math.random() * 2)
      const awayGoals = !isHomeWin ? Math.floor(Math.random() * 3) + 2 : Math.floor(Math.random() * 2)

      const result = `${homeGoals}-${awayGoals}`

      setMatches(matches.map((m) => (m.id === selectedMatch.id ? { ...m, status: "Completed", result } : m)))

      setSimulateMatchOpen(false)
      alert(`Match simulated! Result: ${selectedMatch.homeClub} ${result} ${selectedMatch.awayClub}`)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Football Club Management</h2>
        <Button
          onClick={() => setCreateClubOpen(true)}
          className="bg-secondary text-secondary-foreground hover:bg-secondary/90 gap-2"
        >
          <Plus className="w-4 h-4" />
          Create Club
        </Button>
      </div>

      {/* Clubs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {clubs.map((club) => (
          <Card
            key={club.id}
            className="p-6 border border-border bg-card hover:border-secondary/50 transition-all duration-300 group cursor-pointer"
            onClick={() => {
              setSelectedClub(club)
              setClubDetailOpen(true)
            }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4">{club.name}</h3>

            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  {club.players.length} Players
                </div>
                <div className="text-sm font-semibold text-secondary">{club.rating}/10</div>
              </div>

              <div className="flex items-center gap-2 text-sm text-primary">
                <TrendingUp className="w-4 h-4" />
                {club.wins}W - {club.losses}L - {club.draws}D
              </div>

              <div className="text-xs text-muted-foreground">
                <p>
                  {club.league} • Season {club.season}
                </p>
                {club.nextMatch && <p className="mt-1">{club.nextMatch}</p>}
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full border-secondary/50 text-secondary hover:bg-secondary/10 group-hover:border-secondary transition-all bg-transparent"
            >
              Manage Club
            </Button>
          </Card>
        ))}
      </div>

      {/* Upcoming Matches */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Upcoming Matches</h3>
        <div className="space-y-3">
          {matches
            .filter((m) => m.status !== "Completed")
            .map((match) => (
              <div
                key={match.id}
                className="p-4 rounded-lg bg-background border border-border flex items-center justify-between hover:border-secondary/50 transition-all"
              >
                <div className="flex-1">
                  <p className="font-medium text-foreground">
                    {match.homeClub} vs {match.awayClub}
                  </p>
                  <p className="text-sm text-muted-foreground">{match.date}</p>
                  <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                    <span>Home Rating: {match.homeRating}</span>
                    <span>Away Rating: {match.awayRating}</span>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleSimulateMatch(match)}
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90 gap-2"
                >
                  <Play className="w-4 h-4" />
                  Simulate
                </Button>
              </div>
            ))}
        </div>
      </Card>

      {/* Recent Results */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Recent Results</h3>
        <div className="space-y-3">
          {matches
            .filter((m) => m.status === "Completed")
            .map((match) => (
              <div
                key={match.id}
                className="p-4 rounded-lg bg-background border border-border flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-foreground">
                    {match.homeClub} {match.result} {match.awayClub}
                  </p>
                  <p className="text-sm text-muted-foreground">{match.date}</p>
                </div>
                <Trophy className="w-5 h-5 text-secondary" />
              </div>
            ))}
        </div>
      </Card>

      {/* Create Club Dialog */}
      <Dialog open={createClubOpen} onOpenChange={setCreateClubOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Football Club</DialogTitle>
            <DialogDescription>Start your own club and build a championship team</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Club Name</label>
              <Input
                placeholder="Enter your club name"
                value={newClubName}
                onChange={(e) => setNewClubName(e.target.value)}
                className="bg-background border-border text-foreground placeholder:text-muted-foreground"
              />
            </div>

            <div className="bg-secondary/10 border border-secondary/20 rounded-lg p-3">
              <p className="text-xs text-muted-foreground flex items-start gap-2">
                <Zap className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                <span>
                  Your new club will start in the Premier League with no players. Trade NFTs to build your squad!
                </span>
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => setCreateClubOpen(false)}
              variant="outline"
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateClub}
              disabled={!newClubName.trim()}
              className="flex-1 bg-secondary text-secondary-foreground hover:bg-secondary/90 disabled:opacity-50"
            >
              Create Club
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Club Detail Dialog */}
      <Dialog open={clubDetailOpen} onOpenChange={setClubDetailOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedClub?.name}</DialogTitle>
            <DialogDescription>
              {selectedClub?.wins}W - {selectedClub?.losses}L - {selectedClub?.draws}D • Rating: {selectedClub?.rating}
              /10
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Club Stats */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "League", value: selectedClub?.league },
                { label: "Season", value: selectedClub?.season },
                { label: "Total Players", value: selectedClub?.players.length },
                {
                  label: "Club Value",
                  value: `${(selectedClub?.players.reduce((sum, p) => sum + p.value, 0) || 0).toLocaleString()} FLOW`,
                },
              ].map((stat, i) => (
                <div key={i} className="p-3 rounded-lg bg-background border border-border">
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-sm font-semibold text-foreground mt-1">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Squad */}
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">Squad ({selectedClub?.players.length}/11)</h4>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {selectedClub?.players.map((player) => (
                  <div
                    key={player.id}
                    className="p-3 rounded-lg bg-background border border-border flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-medium text-foreground">{player.name}</p>
                      <p className="text-xs text-muted-foreground">{player.position}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-secondary">{player.rating}</p>
                      <p className="text-xs text-muted-foreground">{player.value.toLocaleString()} FLOW</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t border-border">
            <Button
              onClick={() => setClubDetailOpen(false)}
              className="flex-1 bg-secondary text-secondary-foreground hover:bg-secondary/90"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Match Simulation Dialog */}
      <Dialog open={simulateMatchOpen} onOpenChange={setSimulateMatchOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Simulate Match</DialogTitle>
            <DialogDescription>
              {selectedMatch?.homeClub} vs {selectedMatch?.awayClub}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="text-center flex-1">
                  <p className="text-sm font-semibold text-foreground">{selectedMatch?.homeClub}</p>
                  <p className="text-2xl font-bold text-primary mt-2">{selectedMatch?.homeRating}</p>
                </div>
                <div className="text-center px-4">
                  <p className="text-xs text-muted-foreground">Rating</p>
                </div>
                <div className="text-center flex-1">
                  <p className="text-sm font-semibold text-foreground">{selectedMatch?.awayClub}</p>
                  <p className="text-2xl font-bold text-secondary mt-2">{selectedMatch?.awayRating}</p>
                </div>
              </div>
            </div>

            <p className="text-sm text-muted-foreground text-center">
              Match outcome will be determined by club ratings and randomization. Higher-rated clubs have better chances
              to win.
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => setSimulateMatchOpen(false)}
              variant="outline"
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Cancel
            </Button>
            <Button
              onClick={handleExecuteSimulation}
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
            >
              <Play className="w-4 h-4" />
              Simulate Match
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
