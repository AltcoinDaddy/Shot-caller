"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { TrendingUp, ShoppingCart, Plus, Filter } from "lucide-react"

interface Collectible {
  id: number
  name: string
  rarity: "Common" | "Rare" | "Epic" | "Legendary"
  value: number
  boost: string
  owned: boolean
  image: string
  floorPrice: number
  allTimeHigh: number
  holders: number
  nftId: string
}

interface MarketListing {
  id: number
  collectible: Collectible
  seller: string
  price: number
  listedDate: string
}

export default function Collectibles() {
  const [collectibles] = useState<Collectible[]>([
    {
      id: 1,
      name: "Legendary Player Card",
      rarity: "Legendary",
      value: 250,
      boost: "+25% Fantasy Points",
      owned: true,
      image: "⭐",
      floorPrice: 240,
      allTimeHigh: 350,
      holders: 45,
      nftId: "nft_001",
    },
    {
      id: 2,
      name: "Epic Stadium NFT",
      rarity: "Epic",
      value: 150,
      boost: "+15% Club Rating",
      owned: true,
      image: "🏟️",
      floorPrice: 145,
      allTimeHigh: 200,
      holders: 120,
      nftId: "nft_002",
    },
    {
      id: 3,
      name: "Rare Trophy",
      rarity: "Rare",
      value: 50,
      boost: "+5% Win Rate",
      owned: false,
      image: "🏆",
      floorPrice: 48,
      allTimeHigh: 75,
      holders: 350,
      nftId: "nft_003",
    },
    {
      id: 4,
      name: "Championship Badge",
      rarity: "Legendary",
      value: 300,
      boost: "+30% Tournament Earnings",
      owned: false,
      image: "🥇",
      floorPrice: 290,
      allTimeHigh: 400,
      holders: 30,
      nftId: "nft_004",
    },
    {
      id: 5,
      name: "Golden Boot",
      rarity: "Epic",
      value: 180,
      boost: "+20% Goal Scoring",
      owned: false,
      image: "👢",
      floorPrice: 175,
      allTimeHigh: 250,
      holders: 85,
      nftId: "nft_005",
    },
    {
      id: 6,
      name: "Vintage Jersey",
      rarity: "Rare",
      value: 60,
      boost: "+8% Team Chemistry",
      owned: true,
      image: "👕",
      floorPrice: 55,
      allTimeHigh: 90,
      holders: 280,
      nftId: "nft_006",
    },
  ])

  const [marketListings] = useState<MarketListing[]>([
    {
      id: 1,
      collectible: collectibles[2],
      seller: "Player2",
      price: 52,
      listedDate: "2 hours ago",
    },
    {
      id: 2,
      collectible: collectibles[4],
      seller: "Player3",
      price: 185,
      listedDate: "5 hours ago",
    },
    {
      id: 3,
      collectible: collectibles[3],
      seller: "Player4",
      price: 295,
      listedDate: "1 day ago",
    },
  ])

  const [selectedTab, setSelectedTab] = useState<"marketplace" | "inventory">("marketplace")
  const [selectedCollectible, setSelectedCollectible] = useState<Collectible | null>(null)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [sellDialogOpen, setSellDialogOpen] = useState(false)
  const [sellPrice, setSellPrice] = useState("")
  const [filterRarity, setFilterRarity] = useState<string | null>(null)

  const handleViewDetails = (collectible: Collectible) => {
    setSelectedCollectible(collectible)
    setDetailDialogOpen(true)
  }

  const handleListForSale = (collectible: Collectible) => {
    setSelectedCollectible(collectible)
    setSellPrice("")
    setSellDialogOpen(true)
  }

  const handleSubmitListing = () => {
    if (selectedCollectible && sellPrice) {
      alert(`Listed ${selectedCollectible.name} for ${sellPrice} FLOW`)
      setSellDialogOpen(false)
    }
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "Legendary":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Epic":
        return "bg-purple-500/20 text-purple-400 border-purple-500/30"
      case "Rare":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const userCollectibles = collectibles.filter((c) => c.owned)
  const marketplaceItems = collectibles.filter((c) => !c.owned)
  const filteredMarketplace = filterRarity
    ? marketplaceItems.filter((c) => c.rarity === filterRarity)
    : marketplaceItems

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Collectibles Marketplace</h2>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
          <Plus className="w-4 h-4" />
          Browse Market
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border">
        <button
          onClick={() => setSelectedTab("marketplace")}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            selectedTab === "marketplace"
              ? "text-primary border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Marketplace
        </button>
        <button
          onClick={() => setSelectedTab("inventory")}
          className={`px-4 py-2 text-sm font-medium transition-colors ${
            selectedTab === "inventory"
              ? "text-primary border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Your Inventory ({userCollectibles.length})
        </button>
      </div>

      {/* Marketplace Tab */}
      {selectedTab === "marketplace" && (
        <div className="space-y-6">
          {/* Filters */}
          <div className="flex gap-2 flex-wrap">
            <Button
              onClick={() => setFilterRarity(null)}
              variant={filterRarity === null ? "default" : "outline"}
              size="sm"
              className={filterRarity === null ? "bg-primary text-primary-foreground" : "border-border"}
            >
              <Filter className="w-4 h-4 mr-2" />
              All
            </Button>
            {["Common", "Rare", "Epic", "Legendary"].map((rarity) => (
              <Button
                key={rarity}
                onClick={() => setFilterRarity(rarity)}
                variant={filterRarity === rarity ? "default" : "outline"}
                size="sm"
                className={
                  filterRarity === rarity
                    ? "bg-primary text-primary-foreground"
                    : "border-border text-foreground hover:bg-muted"
                }
              >
                {rarity}
              </Button>
            ))}
          </div>

          {/* Marketplace Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {filteredMarketplace.map((item) => (
              <Card
                key={item.id}
                className="p-6 border border-border bg-card hover:border-primary/50 transition-all duration-300 group cursor-pointer overflow-hidden"
              >
                <div className="relative mb-4">
                  <div className="w-full h-40 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center group-hover:from-primary/30 group-hover:to-secondary/30 transition-all text-4xl">
                    {item.image}
                  </div>
                  <div
                    className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-semibold border ${getRarityColor(item.rarity)}`}
                  >
                    {item.rarity}
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-foreground mb-2">{item.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">{item.boost}</p>

                <div className="space-y-2 mb-4 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Floor Price:</span>
                    <span className="font-semibold text-primary">{item.floorPrice} FLOW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">All-Time High:</span>
                    <span className="font-semibold text-secondary">{item.allTimeHigh} FLOW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Holders:</span>
                    <span className="font-semibold text-foreground">{item.holders}</span>
                  </div>
                </div>

                <Button
                  onClick={() => handleViewDetails(item)}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 group-hover:shadow-lg group-hover:shadow-primary/30 transition-all gap-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  View Listings
                </Button>
              </Card>
            ))}
          </div>

          {/* Active Listings */}
          <Card className="p-6 border border-border bg-card">
            <h3 className="text-lg font-semibold text-foreground mb-4">Active Listings</h3>
            <div className="space-y-3">
              {marketListings.map((listing) => (
                <div
                  key={listing.id}
                  className="p-4 rounded-lg bg-background border border-border flex items-center justify-between hover:border-primary/50 transition-all"
                >
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-2xl">{listing.collectible.image}</span>
                    <div>
                      <p className="font-medium text-foreground">{listing.collectible.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Listed by {listing.seller} • {listing.listedDate}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-primary">{listing.price} FLOW</p>
                    <Button size="sm" className="mt-2 bg-primary text-primary-foreground hover:bg-primary/90">
                      Buy
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* Inventory Tab */}
      {selectedTab === "inventory" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {userCollectibles.map((item) => (
              <Card
                key={item.id}
                className="p-6 border border-border bg-card hover:border-primary/50 transition-all duration-300 group cursor-pointer overflow-hidden"
              >
                <div className="relative mb-4">
                  <div className="w-full h-40 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center group-hover:from-primary/30 group-hover:to-secondary/30 transition-all text-4xl">
                    {item.image}
                  </div>
                  <div
                    className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-semibold border ${getRarityColor(item.rarity)}`}
                  >
                    {item.rarity}
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-foreground mb-2">{item.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">{item.boost}</p>

                <div className="space-y-2 mb-4 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Current Value:</span>
                    <span className="font-semibold text-primary">{item.value} FLOW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Floor Price:</span>
                    <span className="font-semibold text-secondary">{item.floorPrice} FLOW</span>
                  </div>
                </div>

                <Button
                  onClick={() => handleListForSale(item)}
                  className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 group-hover:shadow-lg group-hover:shadow-secondary/30 transition-all"
                >
                  List for Sale
                </Button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Collectible Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedCollectible?.name}</DialogTitle>
            <DialogDescription>{selectedCollectible?.boost}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center text-6xl">
              {selectedCollectible?.image}
            </div>

            <div
              className={`px-3 py-2 rounded text-sm font-semibold border ${getRarityColor(selectedCollectible?.rarity || "Common")}`}
            >
              {selectedCollectible?.rarity}
            </div>

            <div className="space-y-3">
              {[
                { label: "Floor Price", value: `${selectedCollectible?.floorPrice} FLOW` },
                { label: "All-Time High", value: `${selectedCollectible?.allTimeHigh} FLOW` },
                { label: "Total Holders", value: selectedCollectible?.holders },
                { label: "NFT ID", value: selectedCollectible?.nftId },
              ].map((stat, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{stat.label}</span>
                  <span className="font-semibold text-foreground">{stat.value}</span>
                </div>
              ))}
            </div>

            <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
              <p className="text-xs text-muted-foreground flex items-start gap-2">
                <TrendingUp className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <span>This collectible provides a {selectedCollectible?.boost} boost to your gameplay.</span>
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => setDetailDialogOpen(false)}
              variant="outline"
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Close
            </Button>
            <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
              <ShoppingCart className="w-4 h-4" />
              Buy Now
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sell Dialog */}
      <Dialog open={sellDialogOpen} onOpenChange={setSellDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>List {selectedCollectible?.name} for Sale</DialogTitle>
            <DialogDescription>Set your asking price in FLOW</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="bg-background border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-2">Floor Price</p>
              <p className="text-2xl font-bold text-primary">{selectedCollectible?.floorPrice} FLOW</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Your Price</label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Enter price in FLOW"
                  value={sellPrice}
                  onChange={(e) => setSellPrice(e.target.value)}
                  className="bg-background border-border text-foreground placeholder:text-muted-foreground"
                />
                <span className="flex items-center text-muted-foreground">FLOW</span>
              </div>
              {sellPrice && (
                <p className="text-xs text-muted-foreground mt-2">
                  {Number.parseFloat(sellPrice) > (selectedCollectible?.floorPrice || 0)
                    ? `+${(Number.parseFloat(sellPrice) - (selectedCollectible?.floorPrice || 0)).toFixed(2)} above floor`
                    : `${((selectedCollectible?.floorPrice || 0) - Number.parseFloat(sellPrice)).toFixed(2)} below floor`}
                </p>
              )}
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => setSellDialogOpen(false)}
              variant="outline"
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitListing}
              disabled={!sellPrice}
              className="flex-1 bg-secondary text-secondary-foreground hover:bg-secondary/90 disabled:opacity-50"
            >
              List for Sale
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
