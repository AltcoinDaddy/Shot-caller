"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, TrendingUp } from "lucide-react"

interface PlayerListing {
  id: number
  name: string
  position: string
  rating: number
  price: number
  seller: string
  nftId: string
}

export default function PlayerMarketplace() {
  const [listings] = useState<PlayerListing[]>([
    {
      id: 1,
      name: "Vinicius Jr",
      position: "LW",
      rating: 89,
      price: 3800,
      seller: "Player2",
      nftId: "nft_player_001",
    },
    {
      id: 2,
      name: "Jude Bellingham",
      position: "CM",
      rating: 87,
      price: 3500,
      seller: "Player3",
      nftId: "nft_player_002",
    },
    {
      id: 3,
      name: "Florian Wirtz",
      position: "LW",
      rating: 86,
      price: 3200,
      seller: "Player4",
      nftId: "nft_player_003",
    },
    {
      id: 4,
      name: "Bukayo Saka",
      position: "RW",
      rating: 85,
      price: 3000,
      seller: "Player5",
      nftId: "nft_player_004",
    },
  ])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Player Marketplace</h3>
        <Button className="bg-secondary text-secondary-foreground hover:bg-secondary/90">Browse All</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {listings.map((player) => (
          <Card
            key={player.id}
            className="p-4 border border-border bg-card hover:border-secondary/50 transition-all duration-300 group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="text-sm font-semibold text-foreground">{player.name}</h4>
                <p className="text-xs text-muted-foreground">{player.position}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-secondary">{player.rating}</p>
                <Star className="w-4 h-4 text-secondary mt-1" />
              </div>
            </div>

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <TrendingUp className="w-3 h-3" />
                Seller: {player.seller}
              </div>
              <p className="text-sm font-semibold text-primary">{player.price.toLocaleString()} FLOW</p>
            </div>

            <Button
              size="sm"
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 group-hover:shadow-lg group-hover:shadow-secondary/30 transition-all"
            >
              Buy Player
            </Button>
          </Card>
        ))}
      </div>
    </div>
  )
}
