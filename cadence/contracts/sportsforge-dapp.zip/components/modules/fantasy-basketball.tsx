"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Users, Trophy, Zap, Plus, Play, AlertCircle } from "lucide-react"
import { useFantasyBasketball } from "@/lib/hooks/use-fantasy-basketball"
import { useSports } from "@/lib/context/sports-context"

interface Contest {
  id: number
  name: string
  prize: string
  players: number
  maxPlayers: number
  status: "Active" | "Upcoming" | "Completed"
  entryFee: number
  boost: string
  startTime: string
  duration: string
}

interface Player {
  id: number
  name: string
  team: string
  position: string
  points: number
  salary: number
  selected: boolean
}

export default function FantasyBasketball() {
  const { balances } = useSports()
  const { submitLineup, isSubmitting, error } = useFantasyBasketball()

  const [contests] = useState<Contest[]>([
    {
      id: 1,
      name: "NBA Daily Showdown",
      prize: "500 JUICE",
      players: 12,
      maxPlayers: 50,
      status: "Active",
      entryFee: 50,
      boost: "Collectible Boost Available",
      startTime: "Today 7:00 PM",
      duration: "1 day",
    },
    {
      id: 2,
      name: "Weekly Championship",
      prize: "2000 JUICE",
      players: 45,
      maxPlayers: 100,
      status: "Active",
      entryFee: 200,
      boost: "No Boost",
      startTime: "Monday 8:00 PM",
      duration: "7 days",
    },
    {
      id: 3,
      name: "Season Finals",
      prize: "5000 JUICE",
      players: 128,
      maxPlayers: 200,
      status: "Upcoming",
      entryFee: 500,
      boost: "Premium Boost",
      startTime: "Next Friday 6:00 PM",
      duration: "30 days",
    },
  ])

  const [availablePlayers] = useState<Player[]>([
    { id: 1, name: "LeBron James", team: "LAL", position: "SF", points: 28.5, salary: 11000, selected: false },
    { id: 2, name: "Luka Doncic", team: "DAL", position: "PG", points: 32.1, salary: 10500, selected: false },
    { id: 3, name: "Giannis Antetokounmpo", team: "MIL", position: "PF", points: 30.2, salary: 10800, selected: false },
    { id: 4, name: "Stephen Curry", team: "GSW", position: "PG", points: 29.4, salary: 10200, selected: false },
    { id: 5, name: "Kevin Durant", team: "PHX", position: "SF", points: 27.8, salary: 9800, selected: false },
    { id: 6, name: "Jayson Tatum", team: "BOS", position: "SF", points: 26.9, salary: 9500, selected: false },
    { id: 7, name: "Damian Lillard", team: "MIL", position: "PG", points: 24.3, salary: 8900, selected: false },
    {
      id: 8,
      name: "Shai Gilgeous-Alexander",
      team: "OKC",
      position: "PG",
      points: 30.1,
      salary: 10000,
      selected: false,
    },
  ])

  const [selectedPlayers, setSelectedPlayers] = useState<Player[]>([])
  const [selectedContest, setSelectedContest] = useState<Contest | null>(null)
  const [lineupDialogOpen, setLineupDialogOpen] = useState(false)
  const [contestDialogOpen, setContestDialogOpen] = useState(false)

  const maxLineupSize = 5
  const salaryCap = 50000
  const currentSalary = selectedPlayers.reduce((sum, p) => sum + p.salary, 0)
  const remainingSalary = salaryCap - currentSalary

  const handlePlayerSelect = (player: Player) => {
    if (selectedPlayers.find((p) => p.id === player.id)) {
      setSelectedPlayers(selectedPlayers.filter((p) => p.id !== player.id))
    } else if (selectedPlayers.length < maxLineupSize && currentSalary + player.salary <= salaryCap) {
      setSelectedPlayers([...selectedPlayers, player])
    }
  }

  const handleJoinContest = (contest: Contest) => {
    setSelectedContest(contest)
    setContestDialogOpen(true)
  }

  const handleSubmitLineup = async () => {
    if (selectedPlayers.length === maxLineupSize && selectedContest) {
      const success = await submitLineup({
        contestId: selectedContest.id,
        players: selectedPlayers.map((p) => p.id),
        entryFee: selectedContest.entryFee,
      })

      if (success) {
        alert(`Lineup submitted to ${selectedContest.name}! Entry fee: ${selectedContest.entryFee} JUICE`)
        setSelectedPlayers([])
        setContestDialogOpen(false)
      }
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Fantasy Basketball</h2>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
          <Plus className="w-4 h-4" />
          Create Lineup
        </Button>
      </div>

      {/* Contests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {contests.map((contest) => (
          <Card
            key={contest.id}
            className="p-6 border border-border bg-card hover:border-primary/50 transition-all duration-300 group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{contest.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{contest.prize} Prize Pool</p>
              </div>
              <div
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  contest.status === "Active" ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                }`}
              >
                {contest.status}
              </div>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  {contest.players}/{contest.maxPlayers} Players
                </div>
                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
                  {contest.maxPlayers - contest.players} spots left
                </span>
              </div>

              <div className="flex items-center gap-2 text-sm text-secondary">
                <Zap className="w-4 h-4" />
                {contest.boost}
              </div>

              <div className="pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground mb-1">Entry Fee: {contest.entryFee} JUICE</p>
                <p className="text-xs text-muted-foreground">{contest.startTime}</p>
              </div>
            </div>

            <Button
              onClick={() => handleJoinContest(contest)}
              disabled={balances.juice < contest.entryFee}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 group-hover:shadow-lg group-hover:shadow-primary/30 transition-all disabled:opacity-50"
            >
              <Play className="w-4 h-4 mr-2" />
              Join Contest
            </Button>
          </Card>
        ))}
      </div>

      {/* Active Lineups */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Your Active Lineups</h3>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div
              key={i}
              className="p-4 rounded-lg bg-background border border-border flex items-center justify-between hover:border-primary/50 transition-all group"
            >
              <div>
                <p className="font-medium text-foreground">Lineup #{i}</p>
                <p className="text-sm text-muted-foreground">5 Players • +15% Boost • Projected: 245 pts</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold text-primary">+125 JUICE</p>
                  <p className="text-xs text-muted-foreground">Potential Win</p>
                </div>
                <Trophy className="w-5 h-5 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Contest Join Dialog */}
      <Dialog open={contestDialogOpen} onOpenChange={setContestDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Lineup for {selectedContest?.name}</DialogTitle>
            <DialogDescription>
              Select 5 players within the {salaryCap.toLocaleString()} JUICE salary cap
            </DialogDescription>
          </DialogHeader>

          {error && (
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3 flex gap-2">
              <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">{error}</p>
            </div>
          )}

          <div className="space-y-6 py-4">
            {/* Salary Cap Info */}
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Salary Cap</span>
                <span className="text-sm font-semibold text-primary">
                  {currentSalary.toLocaleString()} / {salaryCap.toLocaleString()} JUICE
                </span>
              </div>
              <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
                  style={{ width: `${(currentSalary / salaryCap) * 100}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">Remaining: {remainingSalary.toLocaleString()} JUICE</p>
            </div>

            {/* Selected Players */}
            {selectedPlayers.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">
                  Selected Players ({selectedPlayers.length}/5)
                </h4>
                <div className="space-y-2">
                  {selectedPlayers.map((player) => (
                    <div
                      key={player.id}
                      className="p-3 rounded-lg bg-background border border-primary/30 flex items-center justify-between"
                    >
                      <div>
                        <p className="text-sm font-medium text-foreground">{player.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {player.position} • {player.team}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-semibold text-primary">{player.salary.toLocaleString()}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handlePlayerSelect(player)}
                          className="text-destructive hover:bg-destructive/10"
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Available Players */}
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">Available Players</h4>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {availablePlayers.map((player) => {
                  const isSelected = selectedPlayers.find((p) => p.id === player.id)
                  const canSelect =
                    !isSelected && selectedPlayers.length < maxLineupSize && currentSalary + player.salary <= salaryCap

                  return (
                    <button
                      key={player.id}
                      onClick={() => handlePlayerSelect(player)}
                      disabled={!canSelect && !isSelected}
                      className={`w-full p-3 rounded-lg border transition-all text-left ${
                        isSelected
                          ? "border-primary bg-primary/10"
                          : canSelect
                            ? "border-border bg-card hover:border-primary/50 cursor-pointer"
                            : "border-border bg-muted/30 opacity-50 cursor-not-allowed"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-foreground">{player.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {player.position} • {player.team} • {player.points} pts/game
                          </p>
                        </div>
                        <span className="text-sm font-semibold text-primary">{player.salary.toLocaleString()}</span>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t border-border">
            <Button
              onClick={() => setContestDialogOpen(false)}
              variant="outline"
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitLineup}
              disabled={selectedPlayers.length !== maxLineupSize || isSubmitting}
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {isSubmitting ? "Submitting..." : `Submit Lineup (${selectedContest?.entryFee} JUICE)`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
