"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Zap, X } from "lucide-react"

export default function MemeBetting() {
  const [showBetDialog, setShowBetDialog] = useState(false)
  const [selectedPrediction, setSelectedPrediction] = useState(null)
  const [betAmount, setBetAmount] = useState("")
  const [activeBets, setActiveBets] = useState([
    { id: 1, title: "$FROTH Volatility Spike", amount: 100, odds: 2.5, potential: 250, timeRemaining: "18h" },
    { id: 2, title: "Market Correction", amount: 50, odds: 1.8, potential: 90, timeRemaining: "42h" },
  ])

  const predictions = [
    {
      id: 1,
      title: "$FROTH Volatility Spike",
      odds: "2.5x",
      volatility: "High",
      timeframe: "24h",
      trend: "up",
      description: "FROTH token will experience >15% price movement",
    },
    {
      id: 2,
      title: "Market Correction",
      odds: "1.8x",
      volatility: "Medium",
      timeframe: "48h",
      trend: "down",
      description: "Overall market cap will decrease by 5-10%",
    },
    {
      id: 3,
      title: "FVIX Index Peak",
      odds: "3.2x",
      volatility: "Very High",
      timeframe: "12h",
      trend: "up",
      description: "Flow Volatility Index will exceed 50 points",
    },
  ]

  const handlePlaceBet = (prediction) => {
    setSelectedPrediction(prediction)
    setShowBetDialog(true)
  }

  const handleConfirmBet = () => {
    if (betAmount && selectedPrediction) {
      const newBet = {
        id: activeBets.length + 1,
        title: selectedPrediction.title,
        amount: Number.parseFloat(betAmount),
        odds: Number.parseFloat(selectedPrediction.odds),
        potential: Number.parseFloat(betAmount) * Number.parseFloat(selectedPrediction.odds),
        timeRemaining: selectedPrediction.timeframe,
      }
      setActiveBets([...activeBets, newBet])
      setShowBetDialog(false)
      setBetAmount("")
      setSelectedPrediction(null)
    }
  }

  const handleCloseBet = (betId) => {
    setActiveBets(activeBets.filter((bet) => bet.id !== betId))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Meme Betting with $FROTH</h2>
        <Button
          onClick={() => handlePlaceBet(predictions[0])}
          className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/30"
        >
          <Zap className="w-4 h-4 mr-2" />
          Place Bet
        </Button>
      </div>

      {/* Volatility Index */}
      <Card className="p-6 border border-border bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">FVIX Index</h3>
          <div className="text-3xl font-bold text-primary">42.5</div>
        </div>
        <div className="w-full h-2 bg-background rounded-full overflow-hidden">
          <div className="h-full w-2/3 bg-gradient-to-r from-primary to-secondary" />
        </div>
        <p className="text-sm text-muted-foreground mt-2">Flow Volatility Index - High Activity</p>
        <div className="mt-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" />
          <span className="text-sm text-primary font-medium">+2.3 points in last hour</span>
        </div>
      </Card>

      {/* Prediction Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {predictions.map((pred) => (
          <Card
            key={pred.id}
            className="p-6 border border-border bg-card hover:border-primary/50 transition-all duration-300 group cursor-pointer hover:shadow-lg hover:shadow-primary/20"
          >
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground flex-1">{pred.title}</h3>
              {pred.trend === "up" ? (
                <TrendingUp className="w-5 h-5 text-primary ml-2" />
              ) : (
                <TrendingDown className="w-5 h-5 text-destructive ml-2" />
              )}
            </div>

            <p className="text-sm text-muted-foreground mb-4">{pred.description}</p>

            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Odds</span>
                <span className="font-semibold text-primary">{pred.odds}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Volatility</span>
                <span className="font-semibold text-secondary">{pred.volatility}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Timeframe</span>
                <span className="font-semibold text-foreground">{pred.timeframe}</span>
              </div>
            </div>

            <Button
              onClick={() => handlePlaceBet(pred)}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 group-hover:shadow-lg group-hover:shadow-primary/30 transition-all"
            >
              <Zap className="w-4 h-4 mr-2" />
              Bet Now
            </Button>
          </Card>
        ))}
      </div>

      {/* Active Bets */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Your Active Bets ({activeBets.length})</h3>
        {activeBets.length > 0 ? (
          <div className="space-y-3">
            {activeBets.map((bet) => (
              <div
                key={bet.id}
                className="p-4 rounded-lg bg-background border border-border flex items-center justify-between hover:border-primary/50 transition-all group"
              >
                <div className="flex-1">
                  <p className="font-medium text-foreground">{bet.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {bet.amount} FROTH • {bet.odds}x Odds • {bet.timeRemaining} remaining
                  </p>
                </div>
                <div className="text-right mr-4">
                  <p className="font-semibold text-primary">+{bet.potential.toFixed(0)} FROTH</p>
                  <p className="text-xs text-muted-foreground">Potential Win</p>
                </div>
                <Button
                  onClick={() => handleCloseBet(bet.id)}
                  variant="ghost"
                  size="sm"
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No active bets yet. Place your first bet to get started!</p>
          </div>
        )}
      </Card>

      {/* Bet Dialog */}
      {showBetDialog && selectedPrediction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md border border-border bg-card">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-foreground">Place Bet</h3>
                <button
                  onClick={() => setShowBetDialog(false)}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Prediction</p>
                  <p className="font-semibold text-foreground">{selectedPrediction.title}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Odds</p>
                    <p className="text-lg font-bold text-primary">{selectedPrediction.odds}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Timeframe</p>
                    <p className="text-lg font-bold text-foreground">{selectedPrediction.timeframe}</p>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">Bet Amount (FROTH)</label>
                  <input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full px-4 py-2 rounded-lg bg-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary"
                  />
                </div>

                {betAmount && (
                  <div className="p-3 rounded-lg bg-primary/10 border border-primary/30">
                    <p className="text-sm text-muted-foreground mb-1">Potential Win</p>
                    <p className="text-lg font-bold text-primary">
                      {(Number.parseFloat(betAmount) * Number.parseFloat(selectedPrediction.odds)).toFixed(2)} FROTH
                    </p>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button onClick={() => setShowBetDialog(false)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleConfirmBet}
                    disabled={!betAmount}
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    Confirm Bet
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
