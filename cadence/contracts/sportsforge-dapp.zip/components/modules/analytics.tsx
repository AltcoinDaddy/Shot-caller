"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, Database, Activity, Zap } from "lucide-react"

const performanceData = [
  { day: "Mon", wins: 4, losses: 2, earnings: 450 },
  { day: "Tue", wins: 3, losses: 1, earnings: 320 },
  { day: "Wed", wins: 5, losses: 1, earnings: 680 },
  { day: "Thu", wins: 2, losses: 3, earnings: 180 },
  { day: "Fri", wins: 6, losses: 0, earnings: 920 },
  { day: "Sat", wins: 4, losses: 2, earnings: 550 },
  { day: "Sun", wins: 5, losses: 1, earnings: 750 },
]

const portfolioData = [
  { date: "Week 1", value: 1000 },
  { date: "Week 2", value: 1250 },
  { date: "Week 3", value: 1100 },
  { date: "Week 4", value: 1450 },
  { date: "Week 5", value: 1800 },
]

const onChainMetrics = [
  { name: "Fantasy Basketball", value: 35, color: "#14B8A6" },
  { name: "Football Clubs", value: 28, color: "#06B6D4" },
  { name: "Collectibles", value: 22, color: "#14B8A6" },
  { name: "Meme Bets", value: 15, color: "#06B6D4" },
]

export default function Analytics() {
  const [selectedMetric, setSelectedMetric] = useState("portfolio")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Analytics Dashboard</h2>
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 border border-primary/30">
          <Database className="w-4 h-4 text-primary" />
          <span className="text-sm text-primary font-medium">Find Labs Connected</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Total Earnings", value: "4,850 FLOW", change: "+12.5%", icon: TrendingUp },
          { label: "Win Rate", value: "72%", change: "+5.2%", icon: Activity },
          { label: "Active Assets", value: "24", change: "+3", icon: Zap },
          { label: "Portfolio Value", value: "1,800 FLOW", change: "+18%", icon: Database },
        ].map((stat, i) => {
          const IconComponent = stat.icon
          return (
            <Card key={i} className="p-4 border border-border bg-card hover:border-primary/50 transition-all">
              <div className="flex items-start justify-between mb-2">
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <IconComponent className="w-4 h-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs text-primary mt-2">{stat.change}</p>
            </Card>
          )
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Weekly Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="day" stroke="#A0A0A0" />
              <YAxis stroke="#A0A0A0" />
              <Tooltip
                contentStyle={{ backgroundColor: "#252525", border: "1px solid #333" }}
                labelStyle={{ color: "#F8F8F8" }}
              />
              <Bar dataKey="wins" fill="#14B8A6" />
              <Bar dataKey="losses" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Portfolio Growth</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={portfolioData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" stroke="#A0A0A0" />
              <YAxis stroke="#A0A0A0" />
              <Tooltip
                contentStyle={{ backgroundColor: "#252525", border: "1px solid #333" }}
                labelStyle={{ color: "#F8F8F8" }}
              />
              <Line type="monotone" dataKey="value" stroke="#06B6D4" strokeWidth={2} dot={{ fill: "#14B8A6" }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Asset Allocation (On-Chain)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={onChainMetrics}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {onChainMetrics.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: "#252525", border: "1px solid #333" }}
                labelStyle={{ color: "#F8F8F8" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">On-Chain Insights</h3>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-background border border-border">
              <p className="text-sm text-muted-foreground mb-2">Total Transactions</p>
              <p className="text-2xl font-bold text-primary">1,247</p>
              <p className="text-xs text-primary mt-1">+89 this week</p>
            </div>
            <div className="p-4 rounded-lg bg-background border border-border">
              <p className="text-sm text-muted-foreground mb-2">Gas Efficiency</p>
              <p className="text-2xl font-bold text-secondary">94.2%</p>
              <p className="text-xs text-secondary mt-1">Optimized transactions</p>
            </div>
            <div className="p-4 rounded-lg bg-background border border-border">
              <p className="text-sm text-muted-foreground mb-2">Smart Contract Calls</p>
              <p className="text-2xl font-bold text-primary">342</p>
              <p className="text-xs text-primary mt-1">Verified interactions</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Asset Breakdown */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Portfolio Breakdown</h3>
        <div className="space-y-3">
          {[
            { name: "Fantasy Basketball", value: "35%", color: "from-primary" },
            { name: "Football Clubs", value: "28%", color: "from-secondary" },
            { name: "Collectibles", value: "22%", color: "from-primary" },
            { name: "Meme Bets", value: "15%", color: "from-secondary" },
          ].map((asset, i) => (
            <div key={i}>
              <div className="flex justify-between mb-2">
                <span className="text-sm text-foreground">{asset.name}</span>
                <span className="text-sm font-semibold text-primary">{asset.value}</span>
              </div>
              <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                <div className={`h-full bg-gradient-to-r ${asset.color} to-secondary`} style={{ width: asset.value }} />
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6 border border-border bg-gradient-to-br from-primary/10 to-secondary/10">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          Find Labs Data Status
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Last Query</p>
            <p className="font-semibold text-foreground">2 minutes ago</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-2">Data Freshness</p>
            <p className="font-semibold text-primary">Real-time</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-2">Query Status</p>
            <p className="font-semibold text-primary">Connected</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
