"use client"

import { Card } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const performanceData = [
  { week: "Week 1", wins: 3, losses: 2, earnings: 450 },
  { week: "Week 2", wins: 4, losses: 1, earnings: 620 },
  { week: "Week 3", wins: 5, losses: 0, earnings: 920 },
  { week: "Week 4", wins: 3, losses: 2, earnings: 380 },
]

const playerStats = [
  { name: "LeBron James", appearances: 12, avgPoints: 28.5, winRate: "78%" },
  { name: "Luka Doncic", appearances: 11, avgPoints: 32.1, winRate: "82%" },
  { name: "Giannis Antetokounmpo", appearances: 10, avgPoints: 30.2, winRate: "75%" },
  { name: "Stephen Curry", appearances: 9, avgPoints: 29.4, winRate: "80%" },
]

export default function FantasyBasketballStats() {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-foreground">Your Fantasy Basketball Stats</h3>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Total Contests", value: "24", change: "+3 this week" },
          { label: "Win Rate", value: "72%", change: "+5% this week" },
          { label: "Total Earnings", value: "2,370 JUICE", change: "+620 this week" },
          { label: "Avg Lineup Score", value: "245 pts", change: "+12 pts" },
        ].map((stat, i) => (
          <Card key={i} className="p-4 border border-border bg-card">
            <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-primary mt-2">{stat.change}</p>
          </Card>
        ))}
      </div>

      {/* Performance Chart */}
      <Card className="p-6 border border-border bg-card">
        <h4 className="text-sm font-semibold text-foreground mb-4">Weekly Performance</h4>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="week" stroke="#A0A0A0" />
            <YAxis stroke="#A0A0A0" />
            <Tooltip contentStyle={{ backgroundColor: "#252525", border: "1px solid #333" }} />
            <Bar dataKey="wins" fill="#14B8A6" />
            <Bar dataKey="losses" fill="#EF4444" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Top Players */}
      <Card className="p-6 border border-border bg-card">
        <h4 className="text-sm font-semibold text-foreground mb-4">Your Most Used Players</h4>
        <div className="space-y-3">
          {playerStats.map((player, i) => (
            <div key={i} className="p-3 rounded-lg bg-background border border-border">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">{player.name}</p>
                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">{player.winRate}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{player.appearances} appearances</span>
                <span>{player.avgPoints} avg pts</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
